// CalMobile.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "..\Interface\ICalculator.h"
#include "..\Defination\FactoryMainClass.h"
#include "..\Interface\IMobile.h"
#include <iostream>
using namespace std;


int main()
{
	
	FactoryMainClass *factory = new FactoryMainClass();
	IMobile *m = factory->getMobile();
	m->recieveCall();
	m->makeCall();
	ICalculator *c= NULL;
	c = (ICalculator*)(CMobile*)c;
		m->QueryInterface( c);
	
	c->add();
	c->sub();
	delete m;
	delete factory;
    return 0;
}

