#pragma once
#include "ICalculator.h"

#ifdef INTERFACE_EXPORTS
#define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)
#endif 
class EXIM IMobile
{
public:
	IMobile();
	virtual ~IMobile();
	virtual void makeCall() = 0;
	virtual void recieveCall() = 0;
	virtual void QueryInterface( ICalculator*&) = 0;
};

