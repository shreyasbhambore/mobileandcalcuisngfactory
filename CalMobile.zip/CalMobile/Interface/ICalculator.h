#pragma once

#ifdef INTERFACE_EXPORTS
#define EXIM __declspec(dllexport)
#else
#define EXIM __declspec(dllimport)
#endif 

class EXIM ICalculator
{
public:
	ICalculator();
	~ICalculator();
	virtual void add()=0;
	virtual void sub() = 0;
};

