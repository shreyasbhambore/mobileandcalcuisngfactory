#include "stdafx.h"
#include "ICalculator.h"


ICalculator::ICalculator()
{
}


ICalculator::~ICalculator()
{
}


