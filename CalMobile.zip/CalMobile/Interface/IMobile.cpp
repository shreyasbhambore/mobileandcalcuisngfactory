#include "stdafx.h"
#include "IMobile.h"
#include <iostream>
using namespace std;

IMobile::IMobile()
{
	cout << "IMobile cons" << endl;
}


IMobile::~IMobile()
{
	cout << "IMobile desc" << endl;
}
