#pragma once
#include "..\Interface\IMobile.h"

#ifdef FACTORY_EXPORTS
#define EXIM2 __declspec(dllexport)
#else
#define  EXIM2 __declspec(dllimport)
#endif 

class EXIM2 FactoryClass
{
public:
	FactoryClass();
	~FactoryClass();
	IMobile* getMobile(int i);
};

