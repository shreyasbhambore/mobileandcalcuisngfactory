#include "stdafx.h"
#include "FactoryClass.h"
#include "..\Defination\CCalculator.h"

#include "..\Interface\IMobile.h"
#include "..\Defination\CMobile.h"

FactoryClass::FactoryClass()
{
}


FactoryClass::~FactoryClass()
{
}

CMobile* FactoryClass::getMobile(int i) {

	switch (i)
	{
	case 1: return new CMobile();




	}


}