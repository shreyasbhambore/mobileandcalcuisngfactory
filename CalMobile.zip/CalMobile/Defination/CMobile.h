#pragma once

#include "..\Interface\IMobile.h"
#include "..\Interface\ICalculator.h"

#ifdef DEFINATION_EXPORTS
#define EXIM1 __declspec(dllexport)
#else
#define  EXIM1 __declspec(dllimport)
#endif 

class EXIM1 CMobile:public IMobile,public ICalculator
{
public:
	CMobile();
	~CMobile();
	void makeCall();
	void add();
	void sub();
	void recieveCall();
	void QueryInterface( ICalculator* & );
};

