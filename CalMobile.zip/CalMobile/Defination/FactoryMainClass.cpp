#include "stdafx.h"
#include "FactoryMainClass.h"
#include "..\Defination\CMobile.h"
#include <iostream>
using namespace std;

FactoryMainClass::FactoryMainClass()
{
	cout << "factory cons" << endl;
}


FactoryMainClass::~FactoryMainClass()
{
	cout << "factory destructor" << endl;
}


CMobile* FactoryMainClass::getMobile() {

	
	 return new CMobile();

}