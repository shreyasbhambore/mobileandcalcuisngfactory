#include "stdafx.h"
#include "CMobile.h"
#include "iostream"
using namespace std;

CMobile::CMobile()
{
	cout << "CMobile cons" << endl;
}

CMobile::~CMobile()
{
	cout << "CMobile desc" << endl;
}

void CMobile::add() {
	cout << "add" << endl;
}

void CMobile::sub()
{
	cout << "sub" << endl;
}
void CMobile::makeCall() {
	cout << "makeCall" << endl;
}
void CMobile::recieveCall() {
	cout << "recieveCall" << endl;

}
void CMobile::QueryInterface( ICalculator* &  pInt) {
	
		pInt = (ICalculator*)this; // upcasting
}