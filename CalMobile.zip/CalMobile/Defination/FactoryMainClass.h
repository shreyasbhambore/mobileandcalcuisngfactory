#pragma once
#include "..\Defination\CMobile.h"
#ifdef DEFINATION_EXPORTS
#define EXIM1 __declspec(dllexport)
#else
#define  EXIM1 __declspec(dllimport)
#endif 

class EXIM1 FactoryMainClass
{
public:
	FactoryMainClass();
	~FactoryMainClass();
	CMobile* FactoryMainClass::getMobile();
};