#include "stdafx.h"
#include "CCalculator.h"

#include <iostream>
using namespace std;

CCalculator::CCalculator()
{
}


CCalculator::~CCalculator()
{
}

void CCalculator::add() {
	cout << "add" << endl;
}

void CCalculator::sub() {
	cout << "sub" << endl;
}